﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using RCodingTest.Controllers;

namespace RcodeingTest.UnitTests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void GetPhotoDataList()
        {
            var controller = new ValuesController();
            var url = "http://jsonplaceholder.typicode.com/photos";
            var photoData = controller.GetPhotoData(url);
            Assert.IsNotNull(photoData);
        }

        [TestMethod]
        public void GetAlbumdataList()
        {
            var controller = new ValuesController();
            var url = "http://jsonplaceholder.typicode.com/albums";
            var albumData = controller.GetAlbumsData(url);
            Assert.IsNotNull(albumData);
        }

        
        [TestMethod]
        public void GetDataForUserId1()
        {
            var controller = new ValuesController();
            var albumData = controller.Get(1);
            Assert.IsNotNull(albumData);
            Assert.AreEqual(20, albumData.Count);
        }

        [TestMethod]
        public void Test_GetDataFromUrl()
        {
            var controller = new ValuesController();
            var url = "http://jsonplaceholder.typicode.com/albums";
            var data = controller.GetDataFromUrl(url);
            Assert.IsNotNull(data);
        }

       

    }
}
