﻿using Newtonsoft.Json;
using System.Collections.Generic;
using System.Net;
using System.Web.Http;

namespace RCodingTest.Controllers
{
    public class ValuesController : ApiController
    {
        
        // GET api/values
        public List<string> Get()
        {
            var photoDataList = GetPhotoData("http://jsonplaceholder.typicode.com/photos");
            var albumDataList = GetAlbumsData("http://jsonplaceholder.typicode.com/albums");
            var outPutList = new List<string>();
            if(photoDataList.Count >0 )
            {
                foreach (var photo in photoDataList)
                {
                    outPutList.Add($"Album Id: {photo.AlbumId}, Id: {photo.Id}, Title: {photo.Title}, Url: {photo.Url}, Thumbnail Url: {photo.thumbnailUrl}");
                }
            }

            if (albumDataList.Count > 0)
            {
                foreach (var album in albumDataList)
                {
                    outPutList.Add($"User Id: {album.UserId}, Id: {album.Id}, Title: {album.Title}");
                }
            }           
            return outPutList;
        }

        // GET api/values/59
        public List<string> Get(int id)
        {
            var albumDataList = GetAlbumsData("http://jsonplaceholder.typicode.com/albums?userId=" + id); ;
            var suffix = string.Empty;
            foreach (var album in albumDataList)
            {
                suffix = suffix + $"&id={album.Id}";
            }
            var photoDataList = suffix != string.Empty ? GetPhotoData($"http://jsonplaceholder.typicode.com/photos?"+ suffix.Trim('&')) : new List<PhotoObject>() ;

            var outPutList = new List<string>();
            if (photoDataList.Count > 0)
            {
                foreach (var photo in photoDataList)
                {
                    outPutList.Add($"Album Id: {photo.AlbumId}, Id: {photo.Id}, Title: {photo.Title}, Url: {photo.Url}, Thumbnail Url: {photo.thumbnailUrl}");
                }
            }

            if (albumDataList.Count > 0)
            {
                foreach (var album in albumDataList)
                {
                    outPutList.Add($"User Id: {album.UserId}, Id: {album.Id}, Title: {album.Title}");
                }
            }
            return outPutList; 
        }

        public List<PhotoObject> GetPhotoData(string urlString)
        {
            
            var photoString = GetDataFromUrl(urlString);
            List<PhotoObject> photos = JsonConvert.DeserializeObject<List<PhotoObject>>(photoString);

            return photos;
        }
        
        public string GetDataFromUrl(string url)
        {
            string data = string.Empty;
            using (WebClient client = new WebClient())
            {
                data = client.DownloadString(url);

            }

            return data;
                
        }

        public List<AlbumsObject> GetAlbumsData(string urlString)
        {
            var alumbString = GetDataFromUrl(urlString);
            List<AlbumsObject> albumsList = JsonConvert.DeserializeObject<List<AlbumsObject>>(alumbString);
            return albumsList;
        }


        public class PhotoObject
        {
            public int AlbumId;
            public int Id;
            public string Title;
            public string Url;
            public string thumbnailUrl;
        }
 
        public class AlbumsObject
        {
            public int UserId;
            public int Id;
            public string Title;
        }
    }
}
